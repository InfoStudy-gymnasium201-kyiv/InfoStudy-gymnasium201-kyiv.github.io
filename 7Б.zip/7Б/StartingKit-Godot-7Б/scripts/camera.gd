extends Camera3D

@export_group("Camera Settings")
@export var pan_speed: float = 0.05
@export var zoom_speed: float = 2.0
@export var min_zoom: float = 2.0
@export var max_zoom: float = 30.0

var is_panning: bool = false
var last_mouse_pos: Vector2

func _input(event):
	# 1. Mouse Drag Panning (Middle Mouse Button or Right Click)
	if event is InputEventMouseButton:
		# Use MOUSE_BUTTON_RIGHT if you prefer right-click panning
		if event.button_index == MOUSE_BUTTON_MIDDLE: 
			is_panning = event.pressed
			last_mouse_pos = event.position

	# 2. Moving the camera while holding the button
	if event is InputEventMouseMotion and is_panning:
		var mouse_delta = event.position - last_mouse_pos
		
		# Move the camera on the X and Z axis based on mouse movement
		# We invert the delta so dragging the mouse pulls the map
		var pan_movement = Vector3(-mouse_delta.x, 0, -mouse_delta.y) * pan_speed
		
		# Apply the movement relative to the global world
		global_position += pan_movement
		
		# Update the last mouse position for the next frame
		last_mouse_pos = event.position

	# 3. Scroll Wheel Zooming
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			# Zoom In (Move down along the Y axis)
			global_position.y = clamp(global_position.y - zoom_speed, min_zoom, max_zoom)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			# Zoom Out (Move up along the Y axis)
			global_position.y = clamp(global_position.y + zoom_speed, min_zoom, max_zoom)
